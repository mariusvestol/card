import tkinter as tk
from PIL import Image, ImageTk
import random

heihei = 0


def update_image(i, screen_width, screen_height):
    img = Image.open(f"sp/{exList[i]}.png")
    global answ
    answ = lf[exList[i]-1]
    label.config(text="")

    max_width = screen_width // 3
    max_height = screen_height // 2
    img_ratio = img.width / img.height
    frame_ratio = max_width / max_height

    if img_ratio > frame_ratio:
        new_width = max_width
        new_height = int(max_width / img_ratio)
    else:
        new_height = max_height
        new_width = int(max_height * img_ratio)

    if new_height > screen_height // 2:
        new_height = screen_height // 2
        new_width = int(new_height * img_ratio)

    img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)

    tk_image = ImageTk.PhotoImage(img)


    image_label.config(image=tk_image)
    image_label.image = tk_image

def button_clicked(screen_width, screen_height,myB):
    global heihei
    if myB == True:
    	heihei += 1
    elif myB == False:
    	heihei -= 1
    update_image(heihei, screen_width, screen_height)

def change_label_text():
    if input_field.get() == answ:
        label.config(text="RING RING")
    else:
        label.config(text=f"FEIL DIN FITTE GUTT RIKTIG SVAR ER {answ}")

def create_ui():
    global screen_width, screen_height, input_field, label, image_label 

    root = tk.Tk()
    root.attributes('-fullscreen', True)

    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    image_frame = tk.Frame(root, width=screen_width, height=screen_height // 2)
    image_frame.pack_propagate(False)
    image_frame.pack()

    image_path = "sp/1.png"
    img = Image.open(image_path)

    max_width = screen_width // 3
    max_height = screen_height // 2
    img_ratio = img.width / img.height
    frame_ratio = max_width / max_height

    if img_ratio > frame_ratio:

        new_width = max_width
        new_height = int(max_width / img_ratio)
    else:
        new_height = max_height
        new_width = int(max_height * img_ratio)


    if new_height > screen_height // 2:
        new_height = screen_height // 2
        new_width = int(new_height * img_ratio)

    img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)

    tk_image = ImageTk.PhotoImage(img)

    image_label = tk.Label(image_frame, image=tk_image)
    image_label.place(x=(screen_width - new_width) // 2, y=0)
    global label
    label = tk.Label(root, text="", font=("Helvetica", 16))
    label.pack(side=tk.TOP, pady=10)

    button_frame = tk.Frame(root)
    button_frame.pack(side=tk.BOTTOM, pady=20)

    btn1 = tk.Button(button_frame, text="Forige", command=lambda: button_clicked(screen_width, screen_height, False))
    btn2 = tk.Button(button_frame, text="Svar", command=lambda: change_label_text())
    btn3 = tk.Button(button_frame, text="Neste", command=lambda: button_clicked(screen_width, screen_height, True))

    btn1.pack(side=tk.LEFT, padx=10)
    btn2.pack(side=tk.LEFT, padx=10)
    btn3.pack(side=tk.LEFT, padx=10)

    input_field = tk.Entry(root, width=30, font=("Helvetica", 14))
    input_field.pack(side=tk.BOTTOM, pady=10)

    root.mainloop()



lf = ["('Anne', {'Per': '82.50', 'Anne': '73.00','Svein': '93.50'})",
"[17,19,65,82,99]",
"2",
"00010010",
"1",
"68",
"10010",
"a = 3, b = 6",
"['e',7]",
"[18. 19. 20. 21. 22. 23. 24. 25.]",
"00100101",
"[82, 19, 65, 17, 99]",
"a=0, b=6",
"[2,3,4]",
"10100110",
"120",
"-3",
"None",
"7/2",
"[[20 22] [24 26] [28 30] [32 34]]",
"d",
"[0, 2, 4, 6, 8]",
"d[name] = d.get(name,0)+1",
"7",
"imid = (imin+imax)//2",
"val == liste[imid]:",
"val > values[imid]:",
"return n+sumofn(n-1)",
"3",
"for x in range(1,len(numbers),2):",
"if(num%i)==0:",
"primes.append(num)",
"return not(bool(s.find(s[::-1])))",
"8",
"8",
"32",
"eksamen",
"4"
"35",
"21",
"68",
"itgkerkult",
"CALIFORNIA",
"(6, 12, 18, 24, 30, 36)",
]

answ = lf[0]

exList = []
for i in range(len(lf)):
	exList.append(i)

random.shuffle(exList)


create_ui()

